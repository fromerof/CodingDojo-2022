SET SQL_SAFE_UPDATES = 0;
select * from users;

select * from users where id = 1;
select * from tvshows;
DELETE FROM tvshows;
