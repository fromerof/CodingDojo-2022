
function play(){
    document.getElementById("vid");
    vid.play();
}
function pause(){
    document.getElementById("vid");
    vid.pause();
}

