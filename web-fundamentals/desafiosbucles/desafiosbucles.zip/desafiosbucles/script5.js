var product = 1;
for (var i = 1; i <=12; i++) {
    product = i * product;
}
console.log(product);