
for (var i = 5.5; i >= -3.5 ;i -= 1.5){
    console.log(i);
}