function cerrar(element){
    element.innerText = "Logout"
}

function alerta(element){
    alert("Ninja was liked");
}

function borrar(){
    var elem = document.getElementById("definition");
    elem.parentNode.removeChild(elem);
}